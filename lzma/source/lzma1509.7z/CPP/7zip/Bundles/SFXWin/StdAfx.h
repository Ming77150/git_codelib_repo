// StdAfx.h

#ifndef __STDAFX_H
#define __STDAFX_H

#include "../../../Common/Common.h"

#include <commctrl.h>
#include <ShlObj.h>

// #define printf(x) NO_PRINTF_(x)
// #define sprintf(x) NO_SPRINTF_(x)

#endif
