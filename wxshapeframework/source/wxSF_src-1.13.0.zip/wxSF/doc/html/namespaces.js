var namespaces =
[
    [ "wxSF", "d9/d3d/namespacewx_s_f.html", "d9/d3d/namespacewx_s_f" ],
    [ "wxSFCommonFcn", "dd/da2/namespacewx_s_f_common_fcn.html", "dd/da2/namespacewx_s_f_common_fcn" ],
    [ "wxXS", "de/d57/namespacewx_x_s.html", "de/d57/namespacewx_x_s" ]
];