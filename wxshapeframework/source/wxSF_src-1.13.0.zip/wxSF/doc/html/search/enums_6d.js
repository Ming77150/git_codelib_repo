var searchData=
[
  ['mode',['MODE',['../d8/d5f/classwx_s_f_canvas_history.html#ae1fc48fb8e1c549d2c8c6dd03291732d',1,'wxSFCanvasHistory::MODE()'],['../db/d44/classwx_s_f_shape_canvas.html#a8abb08429b72eb250fc9e278310adfde',1,'wxSFShapeCanvas::MODE()']]]
];
