var searchData=
[
  ['pagesetup',['PageSetup',['../db/d44/classwx_s_f_shape_canvas.html#ae992a3380f2e2af482069e9a402efc7f',1,'wxSFShapeCanvas']]],
  ['paste',['Paste',['../db/d44/classwx_s_f_shape_canvas.html#ababb8df9be41abfd83b029b19d25d4d6',1,'wxSFShapeCanvas']]],
  ['preparegc',['PrepareGC',['../d5/d50/classwx_s_f_scaled_d_c.html#a8b2e5c6b81ad6220dee3efdef7529fdb',1,'wxSFScaledDC']]],
  ['print',['Print',['../db/d44/classwx_s_f_shape_canvas.html#abdb4190533609ba92a248c0116a98f0f',1,'wxSFShapeCanvas::Print(bool prompt=sfPROMPT)'],['../db/d44/classwx_s_f_shape_canvas.html#a88e127294500e99ea574dcc692e37df5',1,'wxSFShapeCanvas::Print(wxSFPrintout *printout, bool prompt=sfPROMPT)']]],
  ['printpreview',['PrintPreview',['../db/d44/classwx_s_f_shape_canvas.html#a7ff36dda3c257f94aa0f45d9b853fd18',1,'wxSFShapeCanvas::PrintPreview()'],['../db/d44/classwx_s_f_shape_canvas.html#a71eaf80f90769dbcfa6b43850a41dccb',1,'wxSFShapeCanvas::PrintPreview(wxSFPrintout *preview, wxSFPrintout *printout=NULL)']]],
  ['processnode',['ProcessNode',['../db/d25/classwx_s_f_layout_vertical_tree.html#a9630682cd1153d38f581572a673708c4',1,'wxSFLayoutVerticalTree::ProcessNode()'],['../d0/d47/classwx_s_f_layout_horizontal_tree.html#a854893e16299cdfeb7a35efab93f07c1',1,'wxSFLayoutHorizontalTree::ProcessNode()']]],
  ['propagateselection',['PropagateSelection',['../db/d44/classwx_s_f_shape_canvas.html#ae83f4916a744b06f738166e9e53862cd',1,'wxSFShapeCanvas']]]
];
