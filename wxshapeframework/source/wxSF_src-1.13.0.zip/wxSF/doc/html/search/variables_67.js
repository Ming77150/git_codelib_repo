var searchData=
[
  ['g_5fpagesetupdata',['g_pageSetupData',['../d9/da2/_shape_canvas_8h.html#a36c1d4cac4cff70dec68bfcff374cbd9',1,'ShapeCanvas.h']]],
  ['g_5fprintdata',['g_printData',['../d9/da2/_shape_canvas_8h.html#ae376168754e6a6d60ffd71b99fa06cd1',1,'ShapeCanvas.h']]]
];
