var searchData=
[
  ['valignbottom',['valignBOTTOM',['../da/d88/classwx_s_f_shape_base.html#ada5980d3365334f22608ddcfe28b970eaabbc3031dc17d12511433fbe06cdaed0',1,'wxSFShapeBase::valignBOTTOM()'],['../db/d44/classwx_s_f_shape_canvas.html#a0277dd3c0d00a9cb44431603a9683dcbaf541d679d3ca7e0082c7be2e457d91c1',1,'wxSFShapeCanvas::valignBOTTOM()']]],
  ['valignexpand',['valignEXPAND',['../da/d88/classwx_s_f_shape_base.html#ada5980d3365334f22608ddcfe28b970eacfae6fd9d73a4e66e42d29bc1479407d',1,'wxSFShapeBase']]],
  ['valignline_5fend',['valignLINE_END',['../da/d88/classwx_s_f_shape_base.html#ada5980d3365334f22608ddcfe28b970eae94ec0b0b5219204cecbe50190b5c5e8',1,'wxSFShapeBase']]],
  ['valignline_5fstart',['valignLINE_START',['../da/d88/classwx_s_f_shape_base.html#ada5980d3365334f22608ddcfe28b970eabc5bcd625a55a29df587cb88611303bc',1,'wxSFShapeBase']]],
  ['valignmiddle',['valignMIDDLE',['../da/d88/classwx_s_f_shape_base.html#ada5980d3365334f22608ddcfe28b970eae1008dad3de2e2d279ad870f151cbbf9',1,'wxSFShapeBase::valignMIDDLE()'],['../db/d44/classwx_s_f_shape_canvas.html#a0277dd3c0d00a9cb44431603a9683dcbabd6a83b19ef521804443de5c9f1cfb95',1,'wxSFShapeCanvas::valignMIDDLE()']]],
  ['valignnone',['valignNONE',['../da/d88/classwx_s_f_shape_base.html#ada5980d3365334f22608ddcfe28b970eaf766c46a41fb162312e82dcecc8e28ac',1,'wxSFShapeBase::valignNONE()'],['../db/d44/classwx_s_f_shape_canvas.html#a0277dd3c0d00a9cb44431603a9683dcba2ea1285d1b15819235af7927fbbf4036',1,'wxSFShapeCanvas::valignNONE()']]],
  ['valigntop',['valignTOP',['../da/d88/classwx_s_f_shape_base.html#ada5980d3365334f22608ddcfe28b970eafc690f59cd1f87971632269e347e752e',1,'wxSFShapeBase::valignTOP()'],['../db/d44/classwx_s_f_shape_canvas.html#a0277dd3c0d00a9cb44431603a9683dcba28a0c75394ebf1ed293cdd07978346ea',1,'wxSFShapeCanvas::valignTOP()']]]
];
