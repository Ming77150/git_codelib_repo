var class_i_d_pair =
[
    [ "IDPair", "d4/d5f/class_i_d_pair.html#a23d413979bef70df4cd35b607419f351", null ],
    [ "m_nNewID", "d4/d5f/class_i_d_pair.html#a1767a35be7ce5eafa84d289bec8ef80f", null ],
    [ "m_nOldID", "d4/d5f/class_i_d_pair.html#a039c2dfedafeca0b3063b47180a10d8d", null ]
];