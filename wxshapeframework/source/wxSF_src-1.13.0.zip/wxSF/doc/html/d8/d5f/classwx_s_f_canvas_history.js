var classwx_s_f_canvas_history =
[
    [ "MODE", "d8/d5f/classwx_s_f_canvas_history.html#ae1fc48fb8e1c549d2c8c6dd03291732d", null ],
    [ "wxSFCanvasHistory", "d8/d5f/classwx_s_f_canvas_history.html#a8f697a2141948c1fc77da65430323a0e", null ],
    [ "wxSFCanvasHistory", "d8/d5f/classwx_s_f_canvas_history.html#afbec8855f8cced07697155a5f4fe088d", null ],
    [ "~wxSFCanvasHistory", "d8/d5f/classwx_s_f_canvas_history.html#ae08269bd94044f868bad5f23b7e64858", null ],
    [ "CanRedo", "d8/d5f/classwx_s_f_canvas_history.html#af0105c3cd458ca7c3efcc2c777271ebb", null ],
    [ "CanUndo", "d8/d5f/classwx_s_f_canvas_history.html#ae0ca0bff463378a9c04664673d427176", null ],
    [ "Clear", "d8/d5f/classwx_s_f_canvas_history.html#a5292ee9dcd43f3f5bd196dc8c965b6d3", null ],
    [ "GetHistoryDepth", "d8/d5f/classwx_s_f_canvas_history.html#a54619eec79dcb300a1ac2f4087ef4b19", null ],
    [ "GetMode", "d8/d5f/classwx_s_f_canvas_history.html#a98241d04c2153e72362e039435f2db05", null ],
    [ "RestoreNewerState", "d8/d5f/classwx_s_f_canvas_history.html#a0e03a75baa3581608a06ed847724e0ac", null ],
    [ "RestoreOlderState", "d8/d5f/classwx_s_f_canvas_history.html#a92a0c179b8d3e1b3df3bd7e84abe31c7", null ],
    [ "SaveCanvasState", "d8/d5f/classwx_s_f_canvas_history.html#acc9102fa1a5e1756ab275a6101c7b19d", null ],
    [ "SetHistoryDepth", "d8/d5f/classwx_s_f_canvas_history.html#ae1b48ee8bfc054a2a24c4c7400ec96e9", null ],
    [ "SetMode", "d8/d5f/classwx_s_f_canvas_history.html#a3a2d482d76bceab493eb86122591a31d", null ],
    [ "SetParentCanvas", "d8/d5f/classwx_s_f_canvas_history.html#aca4f9d6f0269f5ec3d38464599b999df", null ],
    [ "m_lstCanvasStates", "d8/d5f/classwx_s_f_canvas_history.html#a17b8a5f538a7f792efd2f3aa3f362e71", null ],
    [ "m_nHistoryDepth", "d8/d5f/classwx_s_f_canvas_history.html#a84b5f670d1346ebbd0b2b91d6051dd6a", null ],
    [ "m_nWorkingMode", "d8/d5f/classwx_s_f_canvas_history.html#a8c32d22a88011c1a997c00b152346a25", null ],
    [ "m_pCurrentCanvasState", "d8/d5f/classwx_s_f_canvas_history.html#a6971b33235c85fd59480f67df17fde36", null ],
    [ "m_pParentCanvas", "d8/d5f/classwx_s_f_canvas_history.html#aee5985f8e577e5e5358787211a95d751", null ]
];