var classwx_s_f_layout_circle =
[
    [ "wxSFLayoutCircle", "d8/d1e/classwx_s_f_layout_circle.html#a952346d98bf0cd0211d10ca9ce84c750", null ],
    [ "~wxSFLayoutCircle", "d8/d1e/classwx_s_f_layout_circle.html#ab3e34dc2d1c84b0e8a862e00f5b575b1", null ],
    [ "DoLayout", "d8/d1e/classwx_s_f_layout_circle.html#a5d901eaef3bd69d14197bb8df4457bde", null ],
    [ "GetDistanceRatio", "d8/d1e/classwx_s_f_layout_circle.html#a69779ba6a7e7421c7b270797ef440ee3", null ],
    [ "SetDistanceRatio", "d8/d1e/classwx_s_f_layout_circle.html#a4457492905705364a0129217aa913c5b", null ],
    [ "m_DistanceRatio", "d8/d1e/classwx_s_f_layout_circle.html#a23896f2a30fe5583c6036b96b3a02074", null ]
];