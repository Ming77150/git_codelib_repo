var classwx_s_f_layout_algorithm =
[
    [ "~wxSFLayoutAlgorithm", "d9/d29/classwx_s_f_layout_algorithm.html#a60cd9eee73542517416f66cb3f00cafd", null ],
    [ "DoLayout", "d9/d29/classwx_s_f_layout_algorithm.html#a945e9269daefa9ebda3eeaa529ce2e34", null ],
    [ "GetBoundingBox", "d9/d29/classwx_s_f_layout_algorithm.html#abc186e97a825cdff04c6979a694760d2", null ],
    [ "GetShapesCenter", "d9/d29/classwx_s_f_layout_algorithm.html#ad49d1fbbbb5d6a4c112f94f7f8e2497d", null ],
    [ "GetShapesExtent", "d9/d29/classwx_s_f_layout_algorithm.html#acb70ddc196dacc49a33e1942a6928055", null ],
    [ "GetTopLeft", "d9/d29/classwx_s_f_layout_algorithm.html#aafd7042604e16275499e24ac53c6b95f", null ]
];