var classwx_s_f_layout_mesh =
[
    [ "wxSFLayoutMesh", "d9/dc3/classwx_s_f_layout_mesh.html#ae1ea85927247f0df563f2de3ef3b4177", null ],
    [ "~wxSFLayoutMesh", "d9/dc3/classwx_s_f_layout_mesh.html#a80ea6655772fabed92deda7621def395", null ],
    [ "DoLayout", "d9/dc3/classwx_s_f_layout_mesh.html#a5360279b344fcfd648ebaf3c5c85e31d", null ],
    [ "GetHSpace", "d9/dc3/classwx_s_f_layout_mesh.html#a2084f29e1906f839472d9c954b55d90c", null ],
    [ "GetVSpace", "d9/dc3/classwx_s_f_layout_mesh.html#af48aa3d5e6d2a14fa86c79c7a32c98ff", null ],
    [ "SetHSpace", "d9/dc3/classwx_s_f_layout_mesh.html#a720be42e367c61cbb8b18d1f1c2e9bbd", null ],
    [ "SetVSpace", "d9/dc3/classwx_s_f_layout_mesh.html#a74191009834935f0b05ba8bfc0039378", null ],
    [ "m_HSpace", "d9/dc3/classwx_s_f_layout_mesh.html#a3935907fe48dcd469508ecfd67a8e56b", null ],
    [ "m_VSpace", "d9/dc3/classwx_s_f_layout_mesh.html#a8d568afbf0c2fc71f48e67dd931b4dbf", null ]
];