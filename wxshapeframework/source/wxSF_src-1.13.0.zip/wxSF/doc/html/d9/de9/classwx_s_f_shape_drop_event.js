var classwx_s_f_shape_drop_event =
[
    [ "wxSFShapeDropEvent", "d9/de9/classwx_s_f_shape_drop_event.html#a80822e8557e2f33d116d029005acc67f", null ],
    [ "wxSFShapeDropEvent", "d9/de9/classwx_s_f_shape_drop_event.html#a4263962deb57c6ce48b2d45fdda82491", null ],
    [ "~wxSFShapeDropEvent", "d9/de9/classwx_s_f_shape_drop_event.html#a55fc30824fc3ff8e762af1643c9b556d", null ],
    [ "Clone", "d9/de9/classwx_s_f_shape_drop_event.html#a36f15c37c0b37b7c435c961f7cf67b98", null ],
    [ "GetDragResult", "d9/de9/classwx_s_f_shape_drop_event.html#a984ab9788e1b8638e722830c57babec9", null ],
    [ "GetDroppedShapes", "d9/de9/classwx_s_f_shape_drop_event.html#a7ed0d5ed7fd0b3df2ad3f9e1afa877ae", null ],
    [ "GetDropPosition", "d9/de9/classwx_s_f_shape_drop_event.html#a4226fb227d963c9ab7d3f5540fce5872", null ],
    [ "GetDropTarget", "d9/de9/classwx_s_f_shape_drop_event.html#a6826a42ef7fdd8711842001268f32ff8", null ],
    [ "SetDragResult", "d9/de9/classwx_s_f_shape_drop_event.html#a56523296533f6530631a92742c6343fa", null ],
    [ "SetDroppedShapes", "d9/de9/classwx_s_f_shape_drop_event.html#a5e84e2c2569cbb0d6f6032a02e348e7c", null ],
    [ "SetDropPosition", "d9/de9/classwx_s_f_shape_drop_event.html#aca75f9e8aac8f93929e79d4062475091", null ],
    [ "SetDropTarget", "d9/de9/classwx_s_f_shape_drop_event.html#a42a20cb360ea2d13a4bfa9662c3d0efe", null ],
    [ "m_lstDroppedShapes", "d9/de9/classwx_s_f_shape_drop_event.html#a47228d5ddd235b0fa912581fcf522915", null ],
    [ "m_nDragResult", "d9/de9/classwx_s_f_shape_drop_event.html#af4856721964053126db7d1cdebcfbe1b", null ],
    [ "m_nDropPosition", "d9/de9/classwx_s_f_shape_drop_event.html#a2600f4b4e566d42c2baf010e361339f7", null ],
    [ "m_pDropTarget", "d9/de9/classwx_s_f_shape_drop_event.html#af5c83359ed0a528a30532e8ee3f89312", null ]
];